import serial
import csv

#data = [['Iteracion', 'Entrada', 'Salida', 'Tiempo desde sample previo']]
data = []

COMport = 'COM10'
ser = serial.Serial(port=COMport, baudrate=115200, parity=serial.PARITY_NONE,
                    stopbits=serial.STOPBITS_ONE, bytesize=serial.EIGHTBITS)

for i in range(5000):
    d = str(ser.readline())[2:-5].split()
    d.insert(0, i)
    data.append(d)
    print(d)


with open('data.csv', 'w',  newline='')as csvFile:
    writer = csv.writer(csvFile)
    for d in data:
        writer.writerow(d)
